const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const state = JSON.parse(localStorage.getItem('ellieLivingFuture') || '{"xp":0,"worldLevel":1,"missionComplete":false,"step":0}');
function save(){ localStorage.setItem('ellieLivingFuture', JSON.stringify(state)); render(); }
function show(id){ $$('.screen').forEach(s=>s.classList.remove('active')); $('#'+id).classList.add('active'); window.scrollTo(0,0); }
function render(){ $('#xp').textContent=state.xp; $('#futureXp').textContent=state.xp; $('#worldLevel').textContent=state.worldLevel; if(state.missionComplete){ $('#sectorSeven').classList.remove('blackout'); $('#sectorSeven').classList.add('restored'); $('#worldStatus').textContent='Sector Seven restored'; $('#worldDetail').textContent='Power, water, and communications are stable. Your decision changed the district.'; $('#statusDot').className='status-dot safe'; $('#obj1').textContent='✓'; $('#obj2').textContent='✓'; $('#obj3').textContent='✓'; $('#futureBtn').disabled=false; $('#futureBtn').textContent='Enter Future Room'; $('#startMission').textContent='Replay Mission'; }}
render();

const introLines=["There you are. I was hoping you'd come.","Something happened last night.","Sector Seven just went dark.","We don't need another observer. We need you."];
let introIndex=0;
$('#beginBtn').onclick=()=>{ introIndex++; if(introIndex<introLines.length){$('#introLine').textContent=introLines[introIndex]; $('#beginBtn').textContent=introIndex===introLines.length-1?'Open Mission Control':'Continue';} else show('missionControl'); };

const crewMessages={
 Ellie:'Ellie: “Something happened last night. Sector Seven needs us — and I need you.”',
 Elliott:'Elliott: “The reactor output is mathematically sufficient. Which means our problem is somewhere else.”',
 Clyde:'Clyde: “Give me a working power path and I can bring half this place back in minutes.”',
 Gideon:'Gideon: “Before we call this an accident, I want to know why an unauthorized device is on our grid.”',
 Clair:'Clair: “There are families in that district. Whatever plan we choose, people come first.”'
};
$$('.crew').forEach(btn=>btn.onclick=()=>{ $$('.crew').forEach(b=>b.classList.remove('active')); btn.classList.add('active'); $('#crewMessage').textContent=crewMessages[btn.dataset.name]; });
$('#startMission').onclick=()=>{ state.step=0; setupStep0(); show('mission'); };
$('#backBtn').onclick=()=>show('missionControl');
$('#futureBtn').onclick=()=>show('futureRoom');
$('#continueBtn').onclick=()=>show('missionControl');

function feedback(text, good=true){ const f=$('#feedback'); f.classList.remove('hidden'); f.textContent=text; f.style.borderColor=good?'rgba(95,225,162,.35)':'rgba(255,102,139,.4)'; f.style.background=good?'rgba(95,225,162,.09)':'rgba(255,102,139,.08)'; }
function setScene(speaker,title,text,choices){ $('#sceneSpeaker').textContent=speaker; $('#sceneTitle').textContent=title; $('#sceneText').textContent=text; $('#feedback').classList.add('hidden'); $('#choices').innerHTML=''; choices.forEach(c=>{const b=document.createElement('button');b.className='choice';b.textContent=c.label;b.onclick=()=>c.action(b);$('#choices').appendChild(b)}); }
function setupStep0(){ setScene('ELLIOTT // SYSTEMS','The readings don’t add up.','The reactor is producing enough energy, but only 62% reaches the district. What should we investigate first?',[{label:'Trace the unknown power draw',action:()=>step1(true)},{label:'Push the reactor to 120%',action:()=>{feedback('Elliott: “That increases heat without explaining where the missing energy is going. Let’s diagnose before we push harder.”',false)}},{label:'Restart communications first',action:()=>{feedback('Gideon: “Useful later, but comms won’t fix the missing energy. Follow the evidence.”',false)}}]); }
function step1(){ state.xp=Math.max(state.xp,40); save(); $('#obj1').textContent='✓'; setScene('GIDEON // SECURITY','Found it. And it should not be here.','An unauthorized relay is drawing power into a sealed maintenance tunnel. It may be malicious—or it may be keeping something alive. What do you do?',[{label:'Isolate it safely and inspect the load',action:()=>step2('isolate')},{label:'Cut it off immediately',action:()=>step2('cut')},{label:'Ignore it and restore the city around it',action:()=>step2('ignore')}]); }
function step2(choice){ let consequence=''; if(choice==='isolate') consequence='You isolate the relay and discover it is powering an emergency medical shelter that was never added to the new grid map. Clair flags 34 people inside.'; if(choice==='cut') consequence='The unauthorized draw stops—but Clair immediately reports that an emergency shelter lost backup power. You have seconds to reroute energy safely.'; if(choice==='ignore') consequence='The city begins recovering, but the overload remains. Elliott warns the grid could collapse again unless you solve the hidden demand.'; state.xp=Math.max(state.xp,80); save(); feedback(consequence,true); setTimeout(()=>{ $('#obj2').textContent='✓'; setScene('ELLIE // MISSION LEAD','Now make the decision that changes the world.',consequence+' You have one stable energy reserve. Choose how to rebuild the grid.',[{label:'Create a protected microgrid for the shelter, then restore the district',action:()=>finishMission('microgrid')},{label:'Restore the main district first, then address the shelter',action:()=>finishMission('district')},{label:'Split power evenly across every system',action:()=>finishMission('split')}]); },650); }
function finishMission(plan){ const endings={microgrid:'Clyde builds the protected route. The shelter stays online while the district lights return block by block. Elliott records your design as a new resilient-grid model.',district:'The district returns quickly, but the shelter runs close to reserve limits. Ellie marks your result as successful—and adds “protect critical needs earlier” to the next mission briefing.',split:'Everything returns at reduced capacity. It works, but Elliott shows you why equal power is not always the same as smart prioritization. You stabilize the system and learn from the tradeoff.'}; state.missionComplete=true; state.xp=Math.max(state.xp,150); state.worldLevel=2; save(); $('#obj3').textContent='✓'; setScene('ELLIE // MISSION COMPLETE','Sector Seven is alive again.',endings[plan]+' Your first artifact is waiting in the Future Room.',[{label:'Open my Future Room',action:()=>show('futureRoom')},{label:'Return to Mission Control',action:()=>show('missionControl')}]); }

let secs=599; setInterval(()=>{ if(!$('#mission').classList.contains('active'))return; secs=Math.max(0,secs-1); const m=String(Math.floor(secs/60)).padStart(2,'0'); const s=String(secs%60).padStart(2,'0'); $('#timer').textContent=`${m}:${s}`; },1000);

if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./service-worker.js').catch(()=>{}));}
