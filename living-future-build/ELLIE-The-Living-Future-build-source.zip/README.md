# ELLIE: The Living Future

Flagship playable vertical slice for Ellie’s FutureMinds Academy.

## What is already playable
- Cinematic Ellie opening transmission
- Mission Control instead of a lesson dashboard
- Ellie, Elliott, Clyde, Gideon, and Clair with distinct roles
- Sector Seven story mission with choices, feedback, consequences, XP and world progression
- Persistent progress in local storage
- Future Room with the first earned artifact
- Responsive phone/tablet/desktop layout
- PWA/offline cache foundation
- Capacitor configuration for Android/iOS wrapping
- GitHub Actions workflow that can build an Android debug APK

## Product rule
If a feature feels like school software, redesign it until it feels like an adventure.

## Next flagship layers
Living Mission Engine, personalized interests, voice Ellie, saved creations, richer animation/3D world, parent portal, age bands, safe AI backend, crew relationship system, world map, more missions, adaptive learning, accessibility, iOS packaging, signed Android release builds.
